﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class scoreController : MonoBehaviour {
    private int scoreP1 = 0;
    private int scoreP2 = 0;

    public GameObject p1Text;
    public GameObject p2Text;

    public int goalWin;


    private void FixedUpdate(){
        Text uiScoreP1 = this.p1Text.GetComponent<Text>();
        uiScoreP1.text = scoreP1.ToString();

        Text uiScoreP2 = this.p2Text.GetComponent<Text>();
        uiScoreP2.text = scoreP2.ToString();

    }

    private void Update(){
        if(this.scoreP1 >= goalWin || this.scoreP2 >= goalWin){
            SceneManager.LoadScene("GameOver");
        }
    }

    public void goal1(){
        this.scoreP1++;
    }

    public void goal2(){
        this.scoreP2++;
    }
}
