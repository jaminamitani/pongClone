﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ballMovement : MonoBehaviour {
    public float movementSpeed;
    public float addSpeed;
    public float maxSpeed;

    int hitCounter = 0;

	// Use this for initialization
	void Start () {
        StartCoroutine(this.startBall());
	}
   
    public IEnumerator startBall(bool isStartingPlayer1 = true){
        this.positionBall(isStartingPlayer1);
        this.hitCounter = 0;
        yield return new WaitForSeconds(1);
        if (isStartingPlayer1)
            this.moveBall(new Vector2(-1, 0));
        else
            this.moveBall(new Vector2(1, 0));

    }

    public void moveBall(Vector2 direction){
        direction = direction.normalized;
        float speed = this.movementSpeed + this.hitCounter * this.addSpeed;
        Rigidbody2D rb2d = this.gameObject.GetComponent<Rigidbody2D>();
        rb2d.velocity = direction * speed;
    }

    public void incHitCount(){
        if (this.hitCounter * this.addSpeed <= maxSpeed)
            this.hitCounter++;
    }

    public void positionBall(bool isStartingPlayer1){
        this.GetComponent<Rigidbody2D>().velocity = new Vector2(0, 0);
        if (!isStartingPlayer1)
            this.gameObject.transform.localPosition = new Vector3(100, 0, 0);
        else
            this.gameObject.transform.localPosition = new Vector3(-100, 0, 0);
       
    }

}
