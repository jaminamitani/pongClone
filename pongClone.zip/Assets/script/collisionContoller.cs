﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class collisionContoller : MonoBehaviour {

    public ballMovement ballMove;
    public scoreController ScoreCon;

    void bounceFromRacket(Collision2D c){

        Vector3 ballPosition = this.transform.position;
        Vector3 racketPosition = c.gameObject.transform.position;

        float racketHeight = c.collider.bounds.size.y;
        float x;
        if (c.gameObject.name == "Player 1")
            x = 1;
        else 
            x = -1;

        float y = (ballPosition.y - racketPosition.y) / racketHeight;
        this.ballMove.incHitCount();
        this.ballMove.moveBall(new Vector2(x, y));

    }

    private void OnCollisionEnter2D(Collision2D collision){
        if (collision.gameObject.name == "Player 1" || collision.gameObject.name == "Player 2")
            this.bounceFromRacket(collision);
        else if (collision.gameObject.name == "WALL_LEFT"){
            Debug.Log("left");
            this.ScoreCon.goal1();
            StartCoroutine(this.ballMove.startBall(true));

        }
        else if (collision.gameObject.name == "WALL_RIGHT" ){
            Debug.Log("right");
            this.ScoreCon.goal2();
            StartCoroutine(this.ballMove.startBall(false));

        }
    }

}
